// Main application state and utilities
const state = {
  showScrollTop: false,
  currentImageIndex: 0,
  isLightboxOpen: false
};

// Comic data
const comicImages = [
  {
    src: "https://i.ibb.co/mC48mFLt/episode-1.png",
    alt: "DogePepe Comic Episode 1",
    date: "March 15, 2024",
    caption: "The Beginning: Heroes Unite"
  },
  // ... other comic images from the original React state
];

// Utility functions
function createElement(tag, className, content) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (content) element.innerHTML = content;
  return element;
}

// Component creation functions
function createNavbar() {
  const nav = createElement('nav', 'fixed w-full backdrop-blur-md bg-white/30 border-b-4 border-green-400 z-40');
  // ... navbar implementation
  return nav;
}

function createHeroSection() {
  const hero = createElement('div', 'pt-24 pb-16 px-4 section-bg');
  // ... hero section implementation
  return hero;
}

function createGallery() {
  const gallery = createElement('div', 'grid grid-cols-1 lg:grid-cols-3 gap-5 mb-12');
  
  function updateGallery(index) {
    state.currentImageIndex = index;
    const mainImage = gallery.querySelector('.main-image');
    mainImage.src = comicImages[index].src;
    mainImage.alt = comicImages[index].alt;
    // Update thumbnails active state
    // ... thumbnail update logic
  }

  // Create main image
  const mainImageContainer = createElement('div', 'lg:col-span-2 lg:row-span-2 comic-panel aspect-square group');
  // ... main image implementation

  // Create thumbnails
  const thumbnailsContainer = createElement('div', 'grid grid-cols-3 gap-2');
  // ... thumbnails implementation

  return gallery;
}

function createLightbox() {
  const lightbox = createElement('div', 'fixed inset-0 bg-black/90 z-50 flex items-center justify-center');
  
  function closeLightbox() {
    state.isLightboxOpen = false;
    lightbox.remove();
  }

  // ... lightbox implementation
  return lightbox;
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app');
  
  // Lazy loading implementation
  const lazyImages = document.querySelectorAll('img.lazy');
  
  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src;
        img.classList.remove('lazy');
        observer.unobserve(img);
      }
    });
  });

  lazyImages.forEach(img => imageObserver.observe(img));
  
  // Scroll handler
  window.addEventListener('scroll', () => {
    state.showScrollTop = window.scrollY > 400;
    const scrollButton = document.querySelector('.scroll-top-button');
    if (scrollButton) {
      scrollButton.style.display = state.showScrollTop ? 'flex' : 'none';
    }
  });

  // Create and append components
  app.appendChild(createNavbar());
  app.appendChild(createHeroSection());
  
  // Initialize animations
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.1 }
  );

  document.querySelectorAll('.animate-on-scroll').forEach(el => {
    observer.observe(el);
  });
});